import { render, screen } from '@testing-library/react'
import Home from '@/app/page'

describe('Home', () => {
  it('renders the start prompting text', () => {
    render(<Home />)
    const text = screen.getByText('Start prompting.')
    expect(text).toBeInTheDocument()
  })
})