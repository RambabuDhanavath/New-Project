# Next.js Report App CI/CD Pipeline

This repository contains a Next.js application with a complete CI/CD pipeline using GitHub Actions and Netlify deployment.

## Local Development Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/your-username/next-report-app.git
   cd next-report-app
   ```

2. Install dependencies:
   ```bash
   npm install
   ```

3. Run the development server:
   ```bash
   npm run dev
   ```

4. Open [http://localhost:3000](http://localhost:3000) in your browser.

## CI/CD Pipeline Configuration

### GitHub Actions Workflow

The CI/CD pipeline is configured in `.github/workflows/ci.yml` and consists of two main jobs:

1. **Build and Test**
   - Triggered on push to main and pull requests
   - Sets up Node.js environment
   - Installs dependencies
   - Runs build check
   - Executes unit tests

2. **Deploy**
   - Runs only on main branch after successful build and test
   - Builds the application
   - Deploys to Netlify automatically

### Deployment Process

The application is automatically deployed to Netlify when changes are pushed to the main branch. The deployment process:

1. Builds the Next.js application
2. Exports static files to the `out` directory
3. Deploys to Netlify using GitHub Actions

### Environment Variables

Required secrets for deployment:

- `NETLIFY_AUTH_TOKEN`: Your Netlify authentication token
- `NETLIFY_SITE_ID`: Your Netlify site ID

Add these secrets in your GitHub repository settings under "Secrets and variables" > "Actions".

## Known Limitations

1. Static Export
   - The application is configured for static export (`next export`)
   - Server-side features requiring a Node.js runtime won't work
   - API routes are not supported in static exports

2. Environment Variables
   - Public environment variables must be prefixed with `NEXT_PUBLIC_`
   - Secret environment variables should be configured in Netlify's dashboard

## Future Improvements

1. Add Playwright end-to-end tests
2. Implement preview deployments for pull requests
3. Add deployment notifications via Slack/Email
4. Implement smoke tests after deployment
5. Add performance monitoring

## Contributing

1. Fork the repository
2. Create a feature branch
3. Commit your changes
4. Push to your fork
5. Submit a pull request